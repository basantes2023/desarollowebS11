from flask import Flask, render_template
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField
from wtforms.validators import DataRequired, Email

# Crear la aplicación Flask
app = Flask(__name__)  # ← Corrección aquí
app.config['SECRET_KEY'] = 'mysecretkey'  # Clave secreta para formularios

# Definir el formulario
class MiFormulario(FlaskForm):
    nombre = StringField('Nombre', validators=[DataRequired()])
    telefono = StringField('Teléfono', validators=[DataRequired()])
    correo = StringField('Correo Electrónico', validators=[DataRequired(), Email()])
    submit = SubmitField('Enviar')

# Ruta para el formulario
@app.route('/', methods=['GET', 'POST'])
def formulario():
    form = MiFormulario()
    if form.validate_on_submit():
        nombre = form.nombre.data
        telefono = form.telefono.data
        correo = form.correo.data

        # Redirigir a la página de resultado y pasar los valores al template
        return render_template('resultado.html', nombre=nombre, telefono=telefono, correo=correo)

    return render_template('formulario.html', form=form)

# Ruta para la página "About"
@app.route('/about')
def about():
    return render_template('about.html')

# Ruta para la página de inicio
@app.route('/index')
def index():
    return render_template('index.html')

# Iniciar la aplicación
if __name__ == '__main__':  # ← Corrección aquí
    app.run(debug=True)
